# tximport-galaxy-wrapper
Wrapper for the package tximport (https://bioconductor.org/packages/release/bioc/html/tximport.html)
